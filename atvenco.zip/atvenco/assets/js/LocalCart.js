function showCartByLocaleStorage()
{
	
    cartItem = localStorage.getItem('cart');
	cartArr = JSON.parse(cartItem);
    var showCartItem = '';
	var totalCount = 0;
	for(x in cartArr)
	{
        pid = cartArr[x].pid;
		// name = cartArr[x].name;
		//category = cartArr[x].category;	
		showCartItem+=`<div class="cart_product px-3 py-2 mb-2 ">
		<div class="d-flex justify-content-between flex-wrap">
		   
		   <div class="d-flex justify-content-start">
			   <div>
				   <img src="assets/images/product/pro-4.webp" alt="" >
			   </div>
			   <div class="ml-2 cart_product_des">
				   <a href="">
				   <div class="fw_700 f_13 tc_0">Pure Home and Living</div>
				   <div class="f_12 fw_400 tc_0">Blue Midnight Magic</div>
				   <div class="f_12 fw_400 tc_3 text-capitalize">Sold by: DLF brand Pvt ltd.</div>
				   </a>
				   <div class="mt-2 options">
					<select class="fw_700 f_12">
						<option>Size: OnSize</option>
					</select>
					<select class="fw_700 f_12">
						<option>Qty: 1</option>
					</select>
					<span class="f_12 fw_400 tc_6">1 left</span>
				   </div>
			   </div>
		   </div>
		   
		   <div>
			   <div class="fw_700 f_13 text-right">&#x20b9; 875</div>
			   <div class="fw_400 f_13 tc_3"><del>1025</del> <span class="tc_6">30% OFF</span></div>
		   </div>

		</div>

		   <div class="border-top mt-3 p-2 d-flex flex-wrap">
			   <div class="text-uppercase fw_600 tc_3 f_14 border-right px-2 " style="cursor:pointer" onclick="removeCartByLocalStorage('${pid}')">Remove</div>
			   <div class="text-uppercase fw_600 tc_3 f_14 px-2"><a href="" class="tc_3 text-secondary flex-nowrap">Move to wishlist</a></div>
		   </div>

	   </div>`;
			
			totalCount = parseInt(x)+1;	
	}
	
	// if(totalCount==0)
	// {
    //     // console.log('cart empty');
    //     $('.empty-cart').removeClass('d-none');
    //     $('.MyCartBtnLocal').trigger('click');
	// 	$('.not-empty-cart').addClass('d-none');	
	// }
	// else
	// {

    //     // console.log('cart not empty');
    //     // $('.empty-cart').hide();
    //     $('.not-empty-cart').removeClass('d-none');
    //     if(totalCount>1)
    //     {  
    //         // alert(totalCount);
    //         $(".checkoutAllButton").css({'display':'block'});
    //     }
    //     else
    //     {
    //         // alert(totalCount);
    //         $(".checkoutAllButton").css({'display':'none'});
    //     }

	// 	$('.empty-cart').addClass('d-none');
	// }
	// alert(totalCount);
	$("#catItem").html(showCartItem);

}

// showCartByLocaleStorage();


//===================================================Locale Storage Cart Start== Aquib======= 
function addToCartByLocalStorage(pid)
{
	if(localStorage.getItem('cart')==="null" || localStorage.getItem('cart')==null)
	{
		
		// obj = {pid:pid,name:name,category:category};
		obj = {pid:pid};
		ary = [obj];
		// console.log(setCin+','+name+','+category);
		localStorage.setItem('cart',JSON.stringify(ary));
		alert('added in cart');
	}
	else
	{
		cartItem = localStorage.getItem('cart');
		cartArr = JSON.parse(cartItem);
		var existCheck = 0;
		for(x in cartArr)
		{
			// console.log(cartArr[x].cin+'  '+SetCin);
			if(cartArr[x].pid==pid)
			{
				alert('already exist');
				existCheck=1;
				break;
			}
			// else
			// {
						
			// }	
		}
		if(existCheck==0)
		{
			cartArr = JSON.parse(cartItem);
			// obj = {cin:SetCin,name:name,category:category};
			obj = {pid:pid};
			cartArr.push(obj);
			localStorage.setItem('cart',JSON.stringify(cartArr));
			var countCartItem = cartArr.length;
	
			if(countCartItem>0)
			{
    			// console.log('cart empty');
				$('.countCartItem').text(countCartItem);	
			}
			alert('added in cart');

		}
		 
	}
}

function countCartItem()
{
  	var countCartItem = JSON.parse(localStorage.getItem('cart')).length;
	
	if(countCartItem>0)
	{
		$('.countCartItem').text(countCartItem);	
	}

}

function removeCartByLocalStorage(pid)
{
	// console.log(setCin);
	cartItem = localStorage.getItem('cart');
	cartArr = JSON.parse(cartItem);
	for(x in cartArr)
	{
		if(cartArr[x].pid==pid)
		{
			ext = cartArr.splice(x,1);
			// console.log(ext);
			break;
		}
			
	}
	localStorage.setItem('cart',JSON.stringify(cartArr));
	showCartByLocaleStorage();
	countCartItem();	
	// $('.MyCartBtn').trigger('click');
}

function addToCart(pid)
{
	$.ajax(
	{
		url:'control/addToCart.php',
		type:'post',
		data:{pid:pid,addInCart:'yes'},
		beforeSend:function(){

		},
		success:function(res)
		{
			data = JSON.parse(res);
			var countCartItem = data[0];
			$('.countCartItem').text(countCartItem);
			console.log(data[0]);
			alert(data[0]);
		}
	})
}

function removeCartItem(pid)
{
	$.ajax(
	{
		url:'control/addToCart.php',
		type:'post',
		data:{pid:pid,removeFromCart:'yes'},
		beforeSend:function(){
	
		},
		success:function(res)
		{

			console.log(res);
			alert(res);
			if(res=='Cart is empty')
			{
				alert(res);
			}
			else if(res=='cart item Is not deleted')
			{
				alert(res);
			}
			else
			{
				$data = JSON.parse(res);
				var appendData = '';
				var countCartItem = $data.length;
				console.log($data);

				for(x in $data)
				{
					appendData +=`<div class="d-flex justify-content-between flex-wrap">
		   
					<div class="d-flex justify-content-start">
						<div>
							<img src="assets/images/product/pro-4.webp" alt="" >
						</div>
						<div class="ml-2 cart_product_des">
							<a href="">
							<div class="fw_700 f_13 tc_0">Pure Home and Living</div>
							<div class="f_12 fw_400 tc_0">Blue Midnight Magic</div>
							<div class="f_12 fw_400 tc_3 text-capitalize">Sold by: DLF brand Pvt ltd.</div>
							</a>
							<div class="mt-2 options">
							 <select class="fw_700 f_12">
								 <option>Size: OnSize</option>
							 </select>
							 <select class="fw_700 f_12">
								 <option>Qty: 1</option>
							 </select>
							 <span class="f_12 fw_400 tc_6">1 left</span>
							</div>
						</div>
					</div>
					
					<div>
						<div class="fw_700 f_13 text-right">&#x20b9; 875</div>
						<div class="fw_400 f_13 tc_3"><del>1025</del> <span class="tc_6">30% OFF</span></div>
					</div>
		 
				 </div>
		 
					<div class="border-top mt-3 p-2 d-flex flex-wrap">
						<div class="text-uppercase fw_600 tc_3 f_14 border-right px-2 " style="cursor:pointer" onclick="removeCartByLocalStorage('${pid}')">Remove</div>
						<div class="text-uppercase fw_600 tc_3 f_14 px-2"><a href="" class="tc_3 text-secondary flex-nowrap">Move to wishlist</a></div>
					</div>
		 
				</div>`;
					 
				}

				$("#catItem").html(appendData);

				$('.countCartItem').text(countCartItem);
			}	
		}
	})
}
// $('.not-empty-cart').css('display','none!important');
 
