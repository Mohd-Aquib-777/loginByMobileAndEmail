$(".showSignUpForm").click(function()
{
    $(".login_2Section").hide();
    $(".signUpSection").show();
});

$(".showLoginForm").click(function()
{
    $(".login_2Section").show();
    $(".signUpSection").hide();
});

$(".showPassword").click(function()
{   $(this).prev().attr('type','text');
    $(this).hide();
    $(this).next().show();
});

$(".hidePassword").click(function()
{   $(this).prev().prev().attr('type','password');
    $(this).hide();
    $(this).prev().show();
});

var signUpMode = '';

$(".signUpSubmit").click(function(e)
{
    e.preventDefault();
    var email_phone = $("#signUpForm input[name=email_phone]").val();
    var password = $("#signUpForm input[name=password]").val();
    var csrf = $("#signUpForm input[name=csrf]").val();
    // if(email_phone.includes('@'))
    // {
    //     signUpMode = 'email';
    // }
    // else
    // {
    //     signUpMode = 'phone';
    // }
    
    if(email_phone=='' || password=='')
    {
        $("#signUpValidation div").attr('class','alert alert-danger');
        $("#signUpValidation div").html("Please Fill Both Field");
        return false;
    }
    else
    {
        if(signUpMode == 'phone' && email_phone.length<10)
        {
            alert(signUpMode);
            $("#signUpValidation div").attr('class','alert alert-danger');
            $("#signUpValidation div").html("Mobile Length Must Be 10 Digit"); 
            return false;
        }
        
        $.ajax(
        {
            url:siteUrl+'SignUp/existCheck',
            type:'post',
            data:{existCheck:'yes',csrf:csrf,email_phone:email_phone,password:password,signUpMode:signUpMode},
            sendBefore:function()
            {
    
            },
            success:function(res)
            {
                alert(res.trim());
                res = res.trim();        
                if(res=='exist')
                {
                    $("#signUpValidation div").attr('class','alert alert-danger');
                    $("#signUpValidation div").html("Already Exist");
                    flage = 0;                                
                }
                else if(res=='not_exist')
                {
                    window.open('otpForSignUp','_self');
                }
                else
                {
                    $("#signUpValidation div").attr('class','alert alert-danger');
                    
                    $("#signUpValidation div").html(res);
                    
                }
                        
            }                
        });
    }
});

// ===============================

    // $("#signUpForm input[name=email_phone]").keyup(
        
    //     function(){
    //         if(!$("#signUpForm input[name=email_phone]").val().includes('@'))
    //         {
    //             var mobileLen = $("#signUpForm input[name=email_phone]").val().length;
        
    //             if(mobileLen==10)
    //             {
    //                 $("#signUpValidation div").attr('class','');
    //                 $("#signUpValidation div").html('');
    //             }
    //             if(mobileLen>10)
    //             {
    //                 var mobile = $("#signUpForm input[name=email_phone]").val();
    //                 mobile = mobile.substr(0,10);
    //                 $("#signUpForm input[name=email_phone]").val(mobile);
        
    //             }    
    //         }
            
    // });
        
    // $("#signUpForm input[name=email_phone]").change(
    //     function()
    //     {
    //         if(!$("#signUpForm input[name=email_phone]").val().includes('@'))
    //         {
    //             var mobileLen = $("#signUpForm input[name=email_phone]").val().length;
            
    //             if(mobileLen==10)
    //             {
    //                 $("#signUpValidation div").attr('class','');
    //                 $("#signUpValidation div").html('');
    //             }
    //             if(mobileLen>10)
    //             {
    //                 var mobile = $("#signUpForm input[name=email_phone]").val();
    //                 mobile = mobile.substr(0,10);
    //                 $("#signUpForm input[name=phone]").val(mobile);
            
    //             }
    //         }
    // });