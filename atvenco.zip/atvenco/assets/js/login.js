var flage = 0;

$("#loginForm").submit(function(e)
{
    
    if($("#loginForm input[name=phone]").val()=='')
    {
        $("#formValidationNotice").attr('class','alert alert-danger m-3');
        $("#formValidationNotice").html("Enter Mobile No.");
        return false;
    }
    else
    {
        

        var mobileLen = $("#loginForm input[name=phone]").val().length;
        
        if(mobileLen>10 || mobileLen<10)
        {
            $("#formValidationNotice").attr('class','alert alert-danger m-3');
            $("#formValidationNotice").html("Mobile Length Must Be 10 Digit");
            return false;
        }
        // else
        // {
        //     // alert("xdsadsa csdfsd cvdsfds");
           
        //     $.ajax(
        //     {
        //         url:'control/existCheck.php',
        //         type:'post',
        //         data:{csrf:$("#loginForm input[name=csrf]").val(),phone:$("#loginForm input[name=phone]").val()},
        //         sendBefore:function()
        //         {

        //         },
        //         success:function(res)
        //         {
                    
        //             if(res=='exist')
        //             {
        //                 $("#formValidationNotice").attr('class','alert alert-danger m-3');
        //                 $("#formValidationNotice").html("Mobile Already Exist");
        //                 flage = 0;
                                           
        //             }
        //             else
        //             {
        //                 flage=1;
        //             }
        //             // if(res=='not-exist')
        //             // {
        //             //     $("#formValidationNotice").attr('class','alert alert-danger m-3');
        //             //     $("#formValidationNotice").html("Not exist");
        //             //     return false;
        //             // }
                    
        //         }                
        //     });
        //     if(flage)
        //     {
        //         // alert(flage);
        //         return true;
        //     }
        //     else
        //     {
        //         // alert(flage);
        //         return false;
        //     }      
        // }        
    }    
});

$("#loginForm input[name=phone]").keyup(
function(){
    var mobileLen = $("#loginForm input[name=phone]").val().length;

    if(mobileLen==10)
    {
        $("#formValidationNotice").attr('class','');
        $("#formValidationNotice").html('');
    }
    if(mobileLen>10)
    {
        var mobile = $("#loginForm input[name=phone]").val();
        mobile = mobile.substr(0,10);
        $("#loginForm input[name=phone]").val(mobile);

    }
});

$("#loginForm input[name=phone]").change(
function()
{
    var mobileLen = $("#loginForm input[name=phone]").val().length;
    
    if(mobileLen==10)
    {
        $("#formValidationNotice").attr('class','');
        $("#formValidationNotice").html('');
    }
    if(mobileLen>10)
    {
        var mobile = $("#loginForm input[name=phone]").val();
        mobile = mobile.substr(0,10);
        $("#loginForm input[name=phone]").val(mobile);
    
    }
});