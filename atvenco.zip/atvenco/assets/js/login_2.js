$("#login_2Form").submit(function(e)
{
    e.preventDefault();
    var email_phone = $("#login_2Form input[name=email_phone]").val();
    var password = $("#login_2Form input[name=password]").val();
    var login_csrf = $("#login_2Form input[name=csrf]").val();
    if(email_phone!='' && password!='')
    {
        $.ajax(
        {
            url:siteUrl+$("#login_2Form").attr('action'),
            type:'post',
            data:{email_phone:email_phone,password:password,login_csrf:login_csrf},
            beforeSend:function()
            {

            },
            success:function(res)
            {
                alert(res)
                res = res.trim();
                if(res=='success')
                {
                    $("#login_2Form #login_2Validation div").attr('class','alert alert-success');
                    $("#login_2Form #login_2Validation div").html('You Are Successfully Login');
                }
                else
                {
                    $("#login_2Form #login_2Validation div").attr('class','alert alert-danger');
                    $("#login_2Form #login_2Validation div").html(res);   
                }
                
            }
        });
    }
    else
    {
        $("#login_2Form #login_2Validation div").attr('class','alert alert-danger');
        $("#login_2Form #login_2Validation div").html('Please Fill Both Field');
        return false;
    }
});

// $(".login_2Submit").click(function()
// {
//     alert("button click");
// });
