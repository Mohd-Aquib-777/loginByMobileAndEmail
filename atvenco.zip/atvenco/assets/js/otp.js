
$("#otpForm input").keyup(function()
{
    var nextI = $("input").index(this)+1,
    next=$("input").eq(nextI);
    next.focus();
    var otp1 = $("#otpForm input[name=otp1]").val();
    var otp2 = $("#otpForm input[name=otp2]").val();
    var otp3 = $("#otpForm input[name=otp3]").val();
    var otp4 = $("#otpForm input[name=otp4]").val();
    var phone = $("#otpForm input[name=phone]").val();
    var otp_csrf = $("#otpForm input[name=otp_csrf]").val();
    if(otp1!='' && otp2!='' && otp3!='' && otp4!='')
    {
        OTP = otp1+otp2+otp3+otp4;
        alert(OTP);
        $.ajax(
        {
            url:siteUrl+'ForOTP/otpChecker',
            type:'post',
            data:{OTP:OTP,otp_csrf:otp_csrf,phone:phone},
            beforeSend:function()
            {

            },
            success:function(res)
            {
                alert(res);
                res = res.trim();
                if(res=='success')
                {
                    $("#otpValidation").attr('class','alert alert-success');
                    $("#otpValidation").html('You Are Succefully Login');
                }
                if(res=='login-welcome')
                {
                    $("#otpValidation").attr('class','alert alert-success');
                    $("#otpValidation").html('Welcome!And Login Notification');
                }
                if(res=='error')
                {
                    $("#otpValidation").attr('class','alert alert-danger');
                    $("#otpValidation").html('Opps!Error Occur');
                }
                if(res=='wrong-otp')
                {
                    $("#otpValidation").attr('class','alert alert-danger');
                    $("#otpValidation").html('Wrong OTP');
                    $("#otpForm input[name=otp1]").val('');
                    $("#otpForm input[name=otp2]").val('');
                    $("#otpForm input[name=otp3]").val('');
                    $("#otpForm input[name=otp4]").val('');
                }
                if(res=='otp-time-out')
                {
                    $("#otpValidation").attr('class','alert alert-danger');
                    $("#otpValidation").html('OTP Is Expired');
                }
                if(res=='token-not-matched')
                {
                    $("#otpValidation").attr('class','alert alert-danger');
                    $("#otpValidation").html('Token is not matched');
                }
            }

        });            
    }
});

// =====================timer show===========================
var timeCount = 30;
// var otpButtonHideFlage = 0;
 function startTime() 
{
    --timeCount;
         
    $(".timer").html(timeCount);
    
    if(timeCount>=0)
    {
        var t = setTimeout(startTime, 1000);
        $(".showTime").show();
    }
    else
    {
        $(".showTime").hide();
    
        $(".resendOTP").css('display','block');
    }
           
}
startTime();


//============================== resend OTP=====================
$(".resendOTP").click(function()
{
    var otp_csrf = $("#otpForm input[name=otp_csrf]").val();
    
    var phone = $("#otpForm input[name=phone]").val();
    
    $.ajax(
    {
        url:siteUrl+'ForOTP/otpRegeneator',
        type:'post',
        data:{otp_csrf:otp_csrf,phone:phone,generate_otp:'yes'},
        beforeSend:function()
        {

        },
        success:function(res)
        {
            alert(res);
            res = res.trim();
            if(res=='otp-resend')
            {
                $("#otpValidation").attr('class','alert alert-success');
                $("#otpValidation").html('OTP is Resend On your Mobile');
                timeCount = 30;
                $(".resendOTP").hide();
                startTime();    
            }
            if(res=='timeLimitExpire')
            {
                $("#otpValidation").attr('class','alert alert-danger');
                $("#otpValidation").html('Time Over ,session Expire');
                $(".resendOTP").hide();
                $(".showTime").hide();                
            }
            if(res=='resendingLimitCross')
            {
                $("#otpValidation").attr('class','alert alert-danger');
                $("#otpValidation").html('OTP resending Limit Cross');
                $(".resendOTP").hide();
                $(".showTime").hide();
            }
            if(res=='token-not-matched')
            {
                $("#otpValidation").attr('class','alert alert-danger');
                $("#otpValidation").html('Token not matched');
                $(".resendOTP").hide();
                $(".showTime").hide();
            }
            if(res=='2-min-wait')
            {
                $("#otpValidation").attr('class','alert alert-danger');
                $("#otpValidation").html('Wait 2 Minutes');
                timeCount = timeCount;
                $(".resendOTP").hide();
                startTime();
            }
        }
    });
});