
<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 * Model Front_model

 * @package        UCS
 * @category    Model
 * @param     ...
 * @return    ...
 *
 */

class AddUser extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function addUser($phone)
    {
        $this->db->where('phone',$phone);
        
        $query = $this->db->get('user');

        $row = $query->result_array();
        if(isset($row[0]['phone']) && $row[0]['phone']==$phone)
        {return 'exist';}
        else
        {
            $data = ['phone'=>$phone];
            
            $res = $this->db->insert('user',$data);

            if($res)
            {
                return "new_insert";
            }
        }
        // var_dump($row);
    }
}