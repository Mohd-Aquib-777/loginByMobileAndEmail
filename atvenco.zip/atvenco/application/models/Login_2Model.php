
<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 * Model Front_model

 * @package        UCS
 * @category    Model
 * @param     ...
 * @return    ...
 *
 */

class Login_2Model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function loginEmail($email_mobile,$password)
    {
        $this->db->where('email',$email_mobile);
        
        $query = $this->db->get('user');

        $row = $query->result_array();
        
        return $row; 
        // var_dump($row);
    }

    public function loginPhone($email_mobile,$password)
    {
        $this->db->where('phone',$email_mobile);
        
        $query = $this->db->get('user');

        $row = $query->result_array();
        
        return $row; 
    }
}