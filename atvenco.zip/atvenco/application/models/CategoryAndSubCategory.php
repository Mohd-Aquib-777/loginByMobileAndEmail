
<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 * Model Front_model

 * @package        UCS
 * @category    Model
 * @param     ...
 * @return    ...
 *
 */

class CategoryAndSubCategory extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function fetchdata()
    {
    	$ary = [];
    	$query = $this->db->get('category');
    	$ary['category'] = $query->result_array();
    	$query = $this->db->get('sub_category');
    	$ary['sub_category'] = $query->result_array();
     	return $ary;
    }
}