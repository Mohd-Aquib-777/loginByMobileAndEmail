
<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 * Model Front_model

 * @package        UCS
 * @category    Model
 * @param     ...
 * @return    ...
 *
 */

class SignUpModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function existEmail($email_mobile)
    {
        $this->db->where('email',$email_mobile);
        
        $query = $this->db->get('user');

        $row = $query->result_array();
        
        return $row; 
        // var_dump($row);
    }

    public function existPhone($email_mobile)
    {
        $this->db->where('phone',$email_mobile);
        
        $query = $this->db->get('user');

        $row = $query->result_array();
        
        return $row; 
    }
}