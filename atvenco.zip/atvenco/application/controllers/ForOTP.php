<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */
  use Twilio\Rest\Client;

class ForOTP extends CI_Controller
{

  public $otpExpireTime;
  public function __construct()
  {
    parent::__construct();
    $this->otpExpireTime = 10*60; //10 in menutes
  }
  

  function otpGeneator($phone)
  { 
    

    $sid = "AC3286135dbdb40645b3261bf77c4d2d57"; // Your Account SID from www.twilio.com/console
      
    $token = "f31830eef55bb79b09cd7a534de9a94a"; // Your Auth Token from www.twilio.com/console

    $client = new Twilio\Rest\Client($sid, $token);
    
    $_SESSION['otpGenerateCurrentTime'] = time();
    
    if(! isset($_SESSION['otpSendLimit']))
    {
      $_SESSION['otpSendLimit'] = 10;
    }

    $_SESSION['otpSendLimit'] = $_SESSION['otpSendLimit']-1;

    $_SESSION['otp'] = rand(1000,9000);

    // $message = $client->messages->create('+91'.$phone, /*Text this number*/ [
    //       'from' => '+17473224793', // From a valid Twilio number
    //       'body' => 'atvanko for signUp OTP : '.$_SESSION['otp']
    //     ]
    // );
          
    // print $message->sid;    
    // echo "otp_resend";exit;
  
  }

  public function index()
  {
    // $tokenName = $this->security->get_csrf_token_name();
    // var_dump($_REQUEST[$tokenName]);
    // var_dump($this->security->get_csrf_hash());die;
    
    if($_REQUEST['csrf']==$_SESSION['login_csrf'])
    {

      $this->load->model('CategoryAndSubCategory');

      $data = $this->CategoryAndSubCategory->fetchdata();

      $phone = $this->input->get_post('phone');

      $_SESSION['otpSendLimit'] = 5;

      $_SESSION['otp_csrf'] = md5(rand(1000,9999));
    
      $otp_csrf = $_SESSION['otp_csrf'];

      // $_SESSION['otpSendLimit'] = 5;

      $this->otpGeneator($phone);
      
      $this->load->view('otp',$data);
    }
    else
    {
      echo "token not matched";
    }
    
  }
  
  public function otpRegeneator()
  {
    if(isset($_REQUEST['generate_otp']) && $_REQUEST['generate_otp']=='yes')
    {
      $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];
    
      if($limitTime>=30) //wait for 2 min after otp send then this work
      {
        
        // echo $_SESSION['otpSendLimit'].','.$limitTime;
    
        if($limitTime < $this->otpExpireTime && $_SESSION['otpSendLimit'] > 0)
        {
            if(isset($_REQUEST['phone']))
            $phone = $_REQUEST['phone'];
            else
            $phone = $_SESSION['email_phone'];
            $this->otpGeneator($_REQUEST['otp_csrf'],$phone);
            echo 'otp-resend';exit;
        }
        else if($limitTime > $this->otpExpireTime)
        {
            unset($_SESSION['otp_csrf']);
            unset($_SESSION['otpSendLimit']);
            echo "timeLimitExpire";exit;
        }
        else
        {
            unset($_SESSION['otp_csrf']);
            
            echo "resendingLimitCross";exit;
        }
      }
      else
      {
        echo "30-second-wait";exit;
      }
    
    }
  }

  public function otpChecker()
  {
    if($_REQUEST['otp_csrf']==@$_SESSION['otp_csrf'])
    {
        
      $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];
      
      if($_REQUEST['OTP']==$_SESSION['otp'] && $limitTime < 600) //600=10 min
      {
          
        unset($_SESSION['login_csrf']);

        $phone = filter_var($_REQUEST['phone'],FILTER_VALIDATE_INT);
            
        $this->load->model('AddUser');
             
        $res = $this->AddUser->addUser($phone);
        
        if($res=='exist')
        {
          unset($_SESSION['otp_csrf']);
          unset($_SESSION['otp']);
          unset($_SESSION['otpGenerateCurrentTime']);
          unset($_SESSION['otpSendLimit']);
          $_SESSION['auth_user'] = $phone;        
          echo "success";exit;
        }
        if($res=='new_insert')
        {
          unset($_SESSION['otp_csrf']);
          unset($_SESSION['otp']);
          unset($_SESSION['otpGenerateCurrentTime']);
          unset($_SESSION['otpSendLimit']);
          $_SESSION['auth_user']=$phone;
          echo "login-welcome";exit;
        }
        
        // var_dump($res);exit;

        if($conn)
        {

            if($phone)
            {
                $stmt = $conn->prepare("select * from user where phone=?");
                
                $data=[$_REQUEST['phone']];
                
                $stmt->execute($data);
                
                $res = $stmt->fetch(PDO::FETCH_ASSOC);
        
                if(@$res['phone']==$phone) //if exist login
                {
                    unset($_SESSION['otp_csrf']);
                    unset($_SESSION['otp']);
                    unset($_SESSION['otpGenerateCurrentTime']);
                    unset($_SESSION['otpSendLimit']);
                    $_SESSION['auth_user'] = $phone;
                    
                    echo "success";exit;
                }
                else // new registration
                {
                    $query = "insert into user(`phone`) values(?)";

                    $stmt = $conn->prepare($query);

                    $data = [$phone];
                
                    $stmt->execute($data);

                    if($stmt->rowCount())
                    {
                        unset($_SESSION['otp_csrf']);
                        unset($_SESSION['otp']);
                        unset($_SESSION['otpGenerateCurrentTime']);
                        unset($_SESSION['otpSendLimit']);
                        $_SESSION['auth_user']=$phone;
                        echo "login-welcome";exit;
                    }
                    else
                    {
                        echo "error";exit;    
                    }    
                }                
                
            }
        }
      }
      else if($_REQUEST['OTP']!=$_SESSION['otp'])
      {
        echo "wrong-otp";exit;
      }
      else
      {
        echo "otp-time-out";exit;
      }
    }
    else
    {
      echo "token-not-matched";exit;
    }
  }
  
}    