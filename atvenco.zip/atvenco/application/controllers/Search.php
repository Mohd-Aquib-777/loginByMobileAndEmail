<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */

class Search extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    // $this->load->library(array('session','Custom','email'));
    // $this->load->model('Common_model');
    // if($this->session->userdata('logged_in')){
    //   $data['session_user']=$this->session->userdata('logged_in');
    //   $this->load->model('Data');
    //   if(!$this->Data->checkuser($data['session_user']['email'])){
    //          $this->logout();
    //   }
    // }
  }

  public function index()
  {
    $this->load->model('CategoryAndSubCategory');

    $data = $this->CategoryAndSubCategory->fetchdata();

    $this->load->view('search',$data);
  }
}    