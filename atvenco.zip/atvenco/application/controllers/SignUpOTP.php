<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */
use Twilio\Rest\Client;

class SignUpOTP extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('SignUpModel');
  }

  public function otpRegeneator()
  {
    if(isset($_REQUEST['generate_otp']) && $_REQUEST['generate_otp']=='yes')
    {
      $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];
    
      if($limitTime>=30) //wait for 2 min after otp send then this work
      {
        
        // echo $_SESSION['otpSendLimit'].','.$limitTime;
    
        if($limitTime < $this->otpExpireTime && $_SESSION['otpSendLimit'] > 0)
        {
            if(isset($_REQUEST['phone']))
            $phone = $_REQUEST['phone'];
            else
            $phone = $_SESSION['email_phone'];
            $this->otpGeneator($_REQUEST['otp_csrf'],$phone);
            echo 'otp-resend';exit;
        }
        else if($limitTime > $this->otpExpireTime)
        {
            unset($_SESSION['otp_csrf']);
            unset($_SESSION['otpSendLimit']);
            echo "timeLimitExpire";exit;
        }
        else
        {
            unset($_SESSION['otp_csrf']);
            
            echo "resendingLimitCross";exit;
        }
      }
      else
      {
        echo "30-second-wait";exit;
      }
    
    }
  }

  function otpGeneator($phone)
  { 
    

    $sid = "AC3286135dbdb40645b3261bf77c4d2d57"; // Your Account SID from www.twilio.com/console
      
    $token = "f31830eef55bb79b09cd7a534de9a94a"; // Your Auth Token from www.twilio.com/console

    $client = new Twilio\Rest\Client($sid, $token);
    
    $_SESSION['otpGenerateCurrentTime'] = time();
    
    if(! isset($_SESSION['otpSendLimit']))
    {
      $_SESSION['otpSendLimit'] = 10;
    }

    $_SESSION['otpSendLimit'] = $_SESSION['otpSendLimit']-1;

    $_SESSION['otp'] = rand(1000,9000);

    // $message = $client->messages->create('+91'.$phone, /*Text this number*/ [
    //       'from' => '+17473224793', // From a valid Twilio number
    //       'body' => 'atvanko for signUp OTP : '.$_SESSION['otp']
    //     ]
    // );
          
    // print $message->sid;    
    // echo "otp_resend";exit;
  
  }

  public function index()
  {
    $this->load->model('CategoryAndSubCategory');

    $data = $this->CategoryAndSubCategory->fetchdata();
    
    $_SESSION['otp_csrf'] = md5(rand(1000,9999));
    
    $_SESSION['otpGenerateCurrentTime'] = time();
    // require_once './vendor/autoload.php';
  
    // use Twilio\Rest\Client;

    // use PHPMailer\PHPMailer\PHPMailer;
  
    // use PHPMailer\PHPMailer\SMTP;
  
    if($_SESSION['signUpMode']=='phone')
    {

        include_once('control/otpGenerator.php');
  
        if(! isset($_SESSION['otpSendLimit']))
        {
            $_SESSION['otpSendLimit'] = 10;
        }
  
        $otpStatus = otpGeneator($_SESSION['email_phone']);
    }
    // $_SESSION['otpSendLimit'] = 10;
    if($_SESSION['signUpMode']=='email')
    {
        if(! isset($_SESSION['otpSendLimit']))
        {
            $_SESSION['otpSendLimit'] = 10;
        }
        $_SESSION['otp']=rand(1000,9000);  
        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'aquib.debox@gmail.com',
            'smtp_pass' => '786shavez',
            'mailtype'  => 'html',
            'charset'   => 'utf-8'
        );

        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from('aquib.debox@gmail.com', 'atvenco');
        $this->email->to($_SESSION['email_phone']);
        $this->email->subject('OTP Related');
        $this->email->message("OTP IS :".$_SESSION['otp']);
        $this->email->send();
        
        // $mail = new PHPMailer();
    
        // $smtp = SMTP::DEBUG_SERVER;
    
        // $PHPMailer = PHPMailer::ENCRYPTION_STARTTLS;
    
        // include_once('phpMail.php');
    
        // $otpStatus = sendMail1($mail,$smtp,$PHPMailer);    
        $this->load->view('otpForSignUp',$data);
    }

    
  }

  public function resendByEmail()
  {
    if(isset($_REQUEST['generate_otp']) && $_REQUEST['generate_otp']=='yes')
    {
        $otpExpireTime=600;
    
        if($_SESSION['otp_csrf']==$_REQUEST['otp_csrf'])
        {
            $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];
        
            if($limitTime>=30) //wait for 2 min after otp send then this work
            {
            
                // echo $_SESSION['otpSendLimit'].','.$limitTime;
        
                if($limitTime < $otpExpireTime && $_SESSION['otpSendLimit'] > 0)
                {
                    $_SESSION['otp']=rand(1000,9000);

                    $config = Array(
                        'protocol' => 'smtp',
                        'smtp_host' => 'ssl://smtp.googlemail.com',
                        'smtp_port' => 465,
                        'smtp_user' => 'aquib.debox@gmail.com',
                        'smtp_pass' => '786shavez',
                        'mailtype'  => 'html',
                        'charset'   => 'utf-8'
                    );
            
                    $this->email->initialize($config);
                    $this->email->set_newline("\r\n");
                    $this->email->from('aquib.debox@gmail.com', 'atvenco');
                    $this->email->to($_SESSION['email_phone']);
                    $this->email->subject('OTP Related');
                    $this->email->message("OTP IS :".$_SESSION['otp']);
                    $this->email->send();
                    $_SESSION['otpSendLimit'] = $_SESSION['otpSendLimit']-1;
                    echo 'otp-resend';exit;
                }
                else if($limitTime > $otpExpireTime)
                {
                    unset($_SESSION['otp_csrf']);
                    echo "timeLimitExpire";exit;
                }  
                else
                {
                    unset($_SESSION['otp_csrf']);
                    echo "resendingLimitCross";exit;
                }
            }
            else
            {
                echo "30-second-wait";exit;
            }
        }
    }
    
  }
  public function resendByPhone()
  {
    if(isset($_REQUEST['generate_otp']) && $_REQUEST['generate_otp']=='yes')
    {
        $otpExpireTime=600;
    
        if($_SESSION['otp_csrf']==$_REQUEST['otp_csrf'])
        {
            $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];
        
            if($limitTime>=30) //wait for 2 min after otp send then this work
            {
            
                // echo $_SESSION['otpSendLimit'].','.$limitTime;
        
                if($limitTime < $otpExpireTime && $_SESSION['otpSendLimit'] > 0)
                {
                    $otpStatus = otpGeneator($_SESSION['email_phone']);
                    echo 'otp-resend';exit;
                }
                else if($limitTime > $otpExpireTime)
                {
                    unset($_SESSION['otp_csrf']);
                    echo "timeLimitExpire";exit;
                }  
                else
                {
                    unset($_SESSION['otp_csrf']);
                    echo "resendingLimitCross";exit;
                }
            }
            else
            {
                echo "30-second-wait";exit;
            }
        }
    }
    
  }
  

}  