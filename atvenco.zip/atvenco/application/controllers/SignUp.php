<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */

class SignUp extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();

    $this->load->model('SignUpModel');
  }

  public function existCheck()
  {
    if($_REQUEST['csrf']==@$_SESSION['login_csrf'])
    {    
    
        // if($_REQUEST['signUpMode']=='email')
        // {
        
        $email_phone = filter_var($_REQUEST['email_phone'],FILTER_VALIDATE_EMAIL);
        
        if($email_phone)
        {   
            $res = $this->SignUpModel->existEmail($email_phone);
            
            if(@$res[0]['email']==$email_phone)
            {
                echo 'exist';exit;
            }
            else
            {
                $_SESSION['email_phone'] = $email_phone;
                
                $pass = trim(filter_var($_REQUEST['password'],FILTER_SANITIZE_STRING));
                if(!$pass)
                {
                    echo "enter Valid data";exit;
                }
                // $password = $_SESSION['password'];
                // $signUpMode = 'email';
                $_SESSION['password'] = $pass;
                $_SESSION['csrf']=$_REQUEST['csrf'];
                $_SESSION['signUpMode'] = 'email';
                echo "not_exist";exit;
            }  
        }
        else
        {
            $email_phone = filter_var($_REQUEST['email_phone'],FILTER_SANITIZE_NUMBER_INT);
            
            if($email_phone && preg_match('/^[6-9]\d{9}$/', $email_phone))
            {    
                $res = $this->SignUpModel->existPhone($email_phone);
            
                if(@$res[0]['phone']==$email_phone)
                {
                    echo 'exist';exit;
                }
                else
                {
                    $_SESSION['email_phone'] = $email_phone;
                    $pass = trim(filter_var($_REQUEST['password'],FILTER_SANITIZE_STRING));
                    if(!$pass)
                    {
                        echo "enter Valid data";exit;
                    }
                    // $password = $_SESSION['password'];
                    $_SESSION['password'] = $pass;
                    $_SESSION['signUpMode'] = 'phone';
                    $_SESSION['csrf']=$_REQUEST['csrf'];
                    // $signUpMode = 'phone';
                    
                    echo "not_exist";exit;

                }  
            }
            else
            {
                echo "Enter valid Data";exit;
            }
        }
        // }    
    }
    else
    {
        echo "token not matched";exit;
    }
  }
  public function otpChecker()
  {
    if($_REQUEST['otp_csrf']==@$_SESSION['otp_csrf'])
    {
        $limitTime = time()-$_SESSION['otpGenerateCurrentTime'];

        if($_REQUEST['OTP']==$_SESSION['otp'] && $limitTime < 600) //10*60 = 10min
        {
        if(isset($_SESSION['email_phone']) && isset($_SESSION['password']) && isset($_SESSION['signUpMode']))
        {    
            if($_SESSION['signUpMode']=='phone')
            {

                $stmt = $conn->prepare("select * from user where phone=?");
                $data=[$_SESSION['email_phone']];
                $stmt->execute($data);
                $res = $stmt->fetch(PDO::FETCH_ASSOC);
                if(!$res)
                {
                    $query = "insert into user(`phone`,`password`) values(?,?)";
    
                    $stmt = $conn->prepare($query);
    
                    $data = [$_SESSION['email_phone'],$_SESSION['password']];
                    // var_dump($data  );    
                    $stmt->execute($data);
    
                    if($stmt->rowCount())
                    {
                        $phone_email = $_SESSION['email_phone'];
                        session_destroy();
                        @session_start();
                        $_SESSION['auth_user']=$phone_email;
                        echo "login-welcome";exit;
                    }
                    else
                    {
                        echo "error";exit;
                    }
                }
                else
                {
                    echo "Account Exist";exit;
                }
                
            }
            if($_SESSION['signUpMode']=='email')
            {
                $stmt = $conn->prepare("select * from user where email=?");
                $data=[$_SESSION['email_phone']];
                $stmt->execute($data);
                $res = $stmt->fetch(PDO::FETCH_ASSOC);
                if(!$res)
                {
                    $query = "insert into user(`email`,`password`) values(?,?)";
    
                    $stmt = $conn->prepare($query);
    
                    $data = [$_SESSION['email_phone'],$_SESSION['password']];
    
                    $stmt->execute($data);
    
                    if($stmt->rowCount())
                    {
                        
                        $phone_email = $_SESSION['email_phone'];
                        session_destroy();
                        @session_start();
                        $_SESSION['auth_user']=$phone_email;
                        echo "login-welcome";exit;
                    }
                    else
                    {
                        echo "error";exit;
                    }
                }
                else
                {
                    echo "Account Exist";exit;
                }
            }
            
              
        }
        }
        else if($_REQUEST['OTP']!=$_SESSION['otp'])
        {
            echo "wrong-otp";exit;
        }
        else
        {
            echo "otp-time-out";exit;
        }
        
    }
    else
    {
        echo "token-not-matched";exit;
    }
  }
  
}


