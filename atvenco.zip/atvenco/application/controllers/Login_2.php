<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */

class Login_2 extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('Login_2Model');
  }

  public function index()
  {
    $this->load->model('CategoryAndSubCategory');

    $data = $this->CategoryAndSubCategory->fetchdata();
    
    $_SESSION['login_csrf'] = md5(rand(1000,9000));

    $this->load->view('login_2',$data);
  }

  public function login ()
  {
    if(@$_SESSION['login_csrf']==$_REQUEST['login_csrf'])
    {   
      $email_mobile = filter_var($_REQUEST['email_phone'],FILTER_VALIDATE_EMAIL);

      $password = filter_var($_REQUEST['password'],FILTER_SANITIZE_STRING);
      if($email_mobile)
      {
        if(!empty($email_mobile) && !empty($password))
        {   
            $result = $this->Login_2Model->loginEmail($email_mobile,$password);
            // var_dump($result);
            if($result)
            {
                if( $result[0]['email']==$email_mobile && $result[0]['password']==$password)
                {   
                    unset($_SESSION['login_csrf']);
                    $_SESSION['auth_user'] = $email_mobile;
                    echo "success";exit;
                }   
                else if($result[0]['password']!=$password) 
                {
                    echo "Password Is wrong";exit;
                }   
            }
            else
            {
                echo "Account Not Exist";exit;
            }
        }
        // else
        // {
        //     echo "enter valid data";exit;
        // }
      }
      else
      {
        $email_mobile = filter_var($_REQUEST['email_phone'],FILTER_SANITIZE_NUMBER_INT); 
        
        if($email_mobile)
        {
            if(!empty($email_mobile) && !empty($password))
            {   
                $result = $this->Login_2Model->loginPhone($email_mobile,$password);
                
                // var_dump($result);
                if($result)
                {
                    if( $result[0]['phone']==$email_mobile && $result[0]['password']==$password)
                    {   
                        unset($_SESSION['login_csrf']);
                        $_SESSION['auth_user'] = $email_mobile;
                        echo "success";exit;
                    }   
                    else if($result[0]['password']!=$password) 
                    {
                        echo "Password Is wrong";exit;
                    }   
                }
                else
                {
                    echo "Account Not Exist";exit;
                }
            }
            
        }
        else
        {
            echo "enter valid data";exit;
        }

      }
    

    }
    else
    {
        echo "Token Not Matched";exit;
    }
  }


  public function signUp()
  {

  }
}    