<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *
 * Controller Home
 *
 * @package   UCS
 * @category  Frontend
 * @param     ...
 * @return    ...
 *
 */

class ForOTP extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
      
  }
}