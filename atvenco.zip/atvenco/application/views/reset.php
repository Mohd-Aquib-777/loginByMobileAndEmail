<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	 <meta charset="UTF-8">
	 <meta name="description" content="">
	 <meta name="keywords" content="">
	 <meta name="author" content="">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link rel="shortcut icon" href="">
     <link rel="stylesheet" type="text/css" href="assets/css/style_b.css">
     <link rel="stylesheet" type="text/css" href="assets/css/login.css">

     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

     <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

     <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.min.js" integrity="sha512-EY0DoR2OkwOeyNfnJeA6x1oMLZnHLWLmPKYuwIn+7HIqeejx7w9DpUm3lhpfz8iz7K4AvKC4w8Kh8EDgKDYjWA==" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.css" integrity="sha512-JHb2JMOVqJKk0A56YvzOabc7okoyZ4Jc9vE5v/Q6L5WF+x1zru3C2nZqs5skiZoHRqDsqTnWzdpM2SqNkjrPKw==" crossorigin="anonymous" />
     

</head>
 <body>

 <?php include 'header.php'; ?>
 
<!-- ========login=========== -->

    <section class="bg_13">
      <form>
      <div class="reset d-flex justify-content-center mt_80 py-5" >
        <div class="bg-white p-4" style="min-width: 350px;">
          
          <div class="title p-3">
            <div class="f_20 fw_700 text-dark">Reset Password</div>
          </div>
          <div class="subheading px-3">
            <p class="fw_400 tc_3 f_13">Enter your email or mobile number and we 'll send<br> a link on your email to reset your password.</p>
          </div>
          <div class="input_field mb-3 px-3">
            <input type="text" name="" placeholder="Email or Mobile Number">
          </div>
          
          <div class=" px-3 text-center">
            <button class="button text-uppercase text-white fw_700 bg_8 py-2 w-100 border-0">send link</button>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Having trouble logging in?</span><a href="" class="tc_6 text-capitalize fw_700 f_13">Get help</a>
          </div>
        </div>

      </div>
    </form>
    </section>
 
 <?php include 'footer.php'; ?>


  
 </body>
</html>