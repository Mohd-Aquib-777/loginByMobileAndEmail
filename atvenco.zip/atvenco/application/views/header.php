<script>
var siteUrl = '<?=base_url()?>';
</script>
<!-- =======header=========== -->
<header class="desktop_header fixed-top">
  <div class="header_main d-flex px-4  align-items-center justify-content-between">
    <div class="header_left d-flex align-items-center ">
     <div class="logo mr-4">
       <a href="<?=base_url()?>" class="text-dark f_25">Logo</a>
     </div>
     <div class="header_menu d-flex align-items-center">
       
       <div class="Dropdown f_16 fw_600">
        <span>Men</span>
        <div class="Dropdown-content">
            <div class="row p-0">
              <div class="col-xl-4 col-lg-4 col-md-4 pl-4 px-2">
                <h5 class="">Topwear</h5>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul>
              </div>
              <div class="col-xl-4 col-lg-4 col-md-4 bg_3  pl-4 px-2">
                <h5 class="">Topwear</h5>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul>
              </div>

              <div class="col-xl-4 col-lg-4 col-md-4 pl-4 px-2">
                <h5 class="">Topwear</h5>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul>
              </div>

            </div>
          </div>
        </div>
       
       <div class="Dropdown f_16 fw_600">
        <span>Women</span>
        <div class="Dropdown-content">
          <div class="row p-0">
              <div class="col-xl-4 col-lg-4 col-md-4 pl-4 px-2">
                <h5 class="">Topwear</h5>
                <ul type="none">
                  <?php foreach ($sub_category as $key){
                    
                   echo '<li><a href="search/'.$key["id"].'">'.$key["name"].'</a></li>';  
                  } ?>
                  <!-- <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li> -->
                </ul>
              </div>
              <!-- <div class="col-xl-4 col-lg-4 col-md-4 bg_3  pl-4 px-2">
                <h5 class="">Topwear</h5>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul>
              </div>
 -->
            </div>
        </div>
       </div>

       <div class="Dropdown f_16 fw_600">Kids</div>
       <div class="Dropdown f_16 fw_600">Home & Living</div>
       <div class="Dropdown f_16 fw_600">Offers</div>
     </div>
    </div>
    <div class="header_right d-flex align-items-center">
     <div class="search">
       <form>
        <div class="d-flex align-items-center">
         <label><i class="fa fa-search"></i></label>
         <input type="search" name="" placeholder="Search for products, brand and more">
        </div>
       </form>
     </div>
     <div class="menu_right d-flex align-items-center text-center ml-3">
      <div class="Dropdown-2 ml-3">
       <div class="f_12"><i class="far fa-user"></i></div>
       <div class="f_12 fw_600">Profile</div>
        <div class="Dropdown-content-2 pt-2">
          <div class="row pt-3 bg-white">
              <div class="col-xl-12 col-lg-12 col-md-12 p-2">
                <h5 class="f_14 fw_600">Welcome</h5>
                <h6 class="fw_300 f_14">To access account and manage orders</h6>
                <a href="<?=base_url()?>login" class="tc_6">
                <div class="button d-inline p-1 f_14 px-2">
                  Login/Signup
                </div>
                </a>
                <hr>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul>
                <!-- <hr>
                <ul type="none">
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                  <li><a href="">Content</a></li>
                </ul> -->
              </div>
            </div>
        </div>
      </div>
      <div class="Dropdown-2 ml-3">
       <div class="f_12"><i class="far fa-heart"></i></div>
       <div class="f_12 fw_600">Whishlist</div>
      </div>
      <div class="Dropdown-2 ml-3" style="position: relative;">
        <div style="position: absolute;left: 15px;top:10px;background-color: red;height: 18px;width: 18px;" class="f_10 fw_700 rounded-circle text-white countCartItem"></div>
        <a href='<?=base_url()?>cart'><div class="f_12"><img src="assets/images/svg/shopping-bag.svg" width="13px"><?php if(isset($_SESSION['cartItemNo'])){echo $_SESSION['cartItemNo']; } ?></div>
       <div class="f_12 fw_600">Bag</div></a>
      </div>
     </div>
    </div>
  </div>
</header>

<!-- ================mobile header============== -->

<header class="mobile_header fixed-top">
  <div class="header_main d-flex px-4 py-4  align-items-center justify-content-between">
    <div class="header_left d-flex align-items-center ">
     
     <div class="bar">
      <div></div>
      <div></div>
      <div></div>
     </div>

     <div class="ml-3 fw_600 f_20 text-dark">
       Myntra
     </div>

    </div>
    <div class="header_right d-flex align-items-center">
     <div class="menu_right d-flex align-items-center text-center ml-3">
      <div class=" cp ml-3">
       <div class="f_18 text-dark"><i class="fa fa-search text-dark"></i></div>
      </div>
      <div class="ml-3">
       <div class="f_18"><i class="far fa-heart text-dark"></i></div>
      </div>
      <div class="ml-3" style="position: relative;">
        <div style="position: absolute;left: 15px;top:-10px;background-color: red;height: 18px;width: 18px;" class="f_10 fw_700 rounded-circle text-white">1</div>
       <div class="f_18 d-flex justify-content-start"><img src="assets/images/svg/shopping-bag.svg" width="18px"></div>
      </div>
     </div>
    </div>
  </div>


<!-- ===mobile- sidebar=== -->
<div class="mobile_sidebar_layer d-flex">
 <div class="mobile_sidebar"> 
   <div class="banner">
     <img src="assets/images/bann.webp" alt="" width="100%">
   </div>

   <div class="m_menu">
     <ul>
       <li>
        
        <div class="m_menu_link_1">
         <div>Men</div>
         <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
        </div>
         
         <ul class="m_submenu_1">
           <li>
             <div>
             <div>Men</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>

           <li>
             <div>
             <div>Men</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>

           <li>
             <div>
             <div>Men</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
           <li>
             <div>
             <div>Men</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
           <li>
             <div>
             <div>Men</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
         </ul>
       
       </li>

       <li>
        
        <div class="m_menu_link_2">
         <div>Women</div>
         <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
        </div>
         
         <ul class="m_submenu_2">
           <li>
             <div>
             <div>Women</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>

           <li>
             <div>
             <div>Women</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>

           <li>
             <div>
             <div>Women</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
           <li>
             <div>
             <div>Women</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
           <li>
             <div>
             <div>Women</div>
             <div><i class="fas fa-chevron-right fa-sm tc_9"></i></div>
            </div>
           </li>
         </ul>
       
       </li>
     </ul>
   </div>
   
   <hr>
  
   <div class="m_content">
     <ul>
       <li>Contact us</li>
       <li>Gift Card</li>
       <li>Faq</li>
       <li>Legal</li>
     </ul>
   </div>
   

 </div>
 <div class="sidebar_layer" style="position: absolute;width: 20%;right: 0;background-color: rgba(0,0,0,0.6);top:0;height: 100vh;display: none;"></div>
</div>

</header>

<script type="text/javascript">
  $(document).ready(function(){
    $('.m_menu_link_1').click(function(){
      $('.m_submenu_1').toggle();
    })
     $('.m_menu_link_2').click(function(){
      $('.m_submenu_2').toggle();
    })
     $('.bar').click(function(){
      $('.mobile_sidebar').addClass('show');
      $('.sidebar_layer').show();
    })
     $('.sidebar_layer').click(function(){
      $('.mobile_sidebar').removeClass('show');
      $('.sidebar_layer').hide();
    })
    //   $('.mobile_sidebar_layer').click(function(){
    //   $('.mobile_sidebar_layer').removeClass('show');
    // })  

  })
  

function countCartItem()
{
  var countCartItem = JSON.parse(localStorage.getItem('cart')).length;
	
	if(countCartItem>0)
	{
    // console.log('cart empty');
		$('.countCartItem').text(countCartItem);	
	}

}
countCartItem();
</script>