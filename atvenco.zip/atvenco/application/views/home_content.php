<!-- ==============hero slider============ -->

<section>
 <div class="swiper-container mt_80">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <img src="assets/images/slider-1.jpg" alt="" width="100%">
      </div>
      <div class="swiper-slide">
        <img src="assets/images/slider-2.webp" alt="" width="100%">
      </div>
     
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
  
</section>



<!-- ============deal of the day section============= -->

<section class="deal_of_the_day">
  <div class="container-fluid mt_10">
    <div class="col-12 banner_heading">
        <h2 class="rt_20">Deal of the day</h2>
      </div>
    <div class="row mx-auto col-11 pt-3">
      
      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
      <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
       <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6">
        <div class="deal_of_the_day_content">
          <a href="search">
          <img src="assets/images/pro-1.webp" alt="" class="w-100">
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
