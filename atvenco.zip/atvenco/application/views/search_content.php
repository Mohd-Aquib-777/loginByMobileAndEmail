<!-- ==========filter================ -->

<section class="mt_80 search">
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-12 text-center text-white f_14 p-0">
				<p class="fw_700 bg_12 p-0 py-1">- As per guidelines, we are only delivering essentials in govt-specified pincodes - </p>
			</div>

			<div class="search_pagination col-12 f_14">
                <a href="">Home</a> /
                <a href="">Home</a> /
                <a href="">Home</a> /
                <a href="">Home</a>
			</div>

			<div class="search_item col-12 f_14 my-2">
                <span>Gadgets</span>-
                <span>110 items</span>
			</div>

		</div>

		<div class="row mt-3">

			<div class="col-xl-2 col-lg-2 col-md-3 col-12  p-0">

				<div class="search_filter_content" >
					<div class="heading d-flex px-3 justify-content-between align-items-center flex-wrap">
						<h3 class="f_15 text-uppercase ">filters</h3>
						<h3 class="f_12 text-uppercase fw_600 cp">clear all</h3>
					</div>

					<div class="content px-3 mt-2 py-3 border-right border-left border-top">
						<div class="content_haeading d-flex justify-content-between align-items-center">
							<div class="text-uppercase f_14 fw_600">brand</div>
							<div class="d-flex justify-content-center align-items-center cp"><i class="fa fa-search"></i></div>
							<!-- <div class="">
							 <input type="text" name="">
							</div> -->
						</div>

						<div class="mt-3">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">NOISE<span class="f_10 tc_3"> (13)</span></span>
						  <input type="checkbox" checked="checked">
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">One</span>
						  <input type="checkbox" checked="checked">
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">One</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">One</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">One</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

					</div>


					<div class="content px-3 py-3 border-right border-left border-top">
						<div class="content_haeading d-flex justify-content-start align-items-center">
							<div class="text-uppercase f_14 fw_600">Price</div>
							
						</div>

						<div class="mt-3">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">Rs. 1752 to Rs. 2820<span class="f_10 tc_3"> (13)</span></span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">Rs. 1752 to Rs. 2820<span class="f_10 tc_3"> (13)</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">Rs. 1752 to Rs. 2820<span class="f_10 tc_3"> (13)</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">Rs. 1752 to Rs. 2820<span class="f_10 tc_3"> (13)</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14">Rs. 1752 to Rs. 2820<span class="f_10 tc_3"> (13)</span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

					</div>

					<div class="content px-3 py-3 border-right border-left border-top border-bottom">
						<div class="content_haeading d-flex justify-content-start align-items-center">
							<div class="text-uppercase f_14 fw_600">Color</div>
							
						</div>

						<div class="mt-3">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14 color_circle d-flex align-items-start">
						   	<div class="mr-1 align-self-center"></div> 
						   	 Black
						   	<span class="f_10 tc_3 align-self-center ml-1"> (13)</span>
						   </span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14 color_circle d-flex align-items-start">
						   	<div class="mr-1 align-self-center bg-success"></div> 
						   	 Green
						   	<span class="f_10 tc_3 align-self-center ml-1"> (13)</span>
						   </span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14 color_circle d-flex align-items-start">
						   	<div class="mr-1 align-self-center bg-warning"></div> 
						   	 Yellow
						   	<span class="f_10 tc_3 align-self-center ml-1"> (13)</span>
						   </span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14 color_circle d-flex align-items-start">
						   	<div class="mr-1 align-self-center bg-white border"></div> 
						   	 white
						   	<span class="f_10 tc_3 align-self-center ml-1"> (13)</span>
						   </span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

						<div class="">
						 <label class="Checkbox d-flex align-items-start">
						   <span class="f_14 color_circle d-flex align-items-start">
						   	<div class="mr-1 align-self-center bg-primary"></div> 
						   	 Blue
						   	<span class="f_10 tc_3 align-self-center ml-1"> (13)</span>
						   </span>
						  <input type="checkbox" >
						  <span class="checkmark"></span>
						</label>	
						</div>

					</div>



				</div>
			</div>

			<!-- =============product============== -->
			<div class="col-xl-10 col-lg-10 col-md-9 col-12">
				<div class="row product_heading_pan mb-3 pb-3">
					<div class="col-xl-9 col-lg-9 col-md-8 col-sm-6 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="d-flex flex-wrap">

						<div class="button active d-flex align-items-start px-2">
							<div class="mr-1 tc_7 f_14 fw_400">Bundles</div>
							<div><i class="fas fa-angle-down tc_9 fw_300 f_14"></i></div>
						</div>

						<div class="button d-flex align-items-start px-2">
							<div class="mr-1 tc_7 f_14 fw_400">Bundles</div>
							<div><i class="fas fa-angle-down tc_9 fw_300 f_14"></i></div>
						</div>

						<div class="button d-flex align-items-start px-2">
							<div class="mr-1 tc_7 f_14 fw_400">Bundles</div>
							<div><i class="fas fa-angle-down tc_9 fw_300 f_14"></i></div>
						</div>

						<div class="button d-flex align-items-start px-2">
							<div class="mr-1 tc_7 f_14 fw_400">Bundles</div>
							<div><i class="fas fa-angle-down tc_9 fw_300 f_14"></i></div>
						</div>
						<div class="button d-flex align-items-start px-2">
							<div class="mr-1 tc_7 f_14 fw_400">Bundles</div>
							<div><i class="fas fa-angle-down tc_9 fw_300 f_14"></i></div>
						</div>



					    </div>

					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="sort_by">
							<div class="f_14">

							<span>Sort by: <span class="fw_700">Recommended</span></span>
                            <i class="fas fa-angle-down tc_9 fw_300 f_14 ml-2"></i>
                            </div>
							<ul type="none" class="pt-3">
								<li><a href="">What's New</a></li>
								<li><a href="">What's New</a></li>
								<li><a href="">What's New</a></li>
								<li><a href="">What's New</a></li>
								<li><a href="">What's New</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="row">
						
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12 mb-xl-0 mb-lg-0 mb-2">
						<div class="search_product p-3">
						  <a href="product" class="text-dark">	
							<div class="img">
								<img src="assets/images/product/pro-1.webp" alt="" width="100%">
							</div>
							<div class="pro_content">
								<div class="f_12 font-weight-bold mb-3">4 <i class="fa fa-star tc_8"></i> | 6.5k</div>
								<div class="f_15 text-uppercase font-weight-bold b_name">Noise</div>
								<div class="p_name f_14 tc_7 text-capitalize">beat truly wirless</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799 
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                            
							<div class="pro_content_overlay">
								<div class="f_12 font-weight-bold mb-4"></div>
								<div class="f_15 text-uppercase b_name">
									<button class="text-uppercase border f_14 fw_600 text-dark w-100 px-2 py-1 bg-white"><i class="far fa-heart"></i> wishlist</button>
								</div>
								<div class="p_name f_14 tc_7 text-capitalize mt-1">Sizes: Onesize</div>
								<div class="p_price f_14 font-weight-bold mt-1">
									Rs. 1799
									<span class="fw_400 f_12 tc_7"><del>Rs. 4000</del></span>
									<span class="fw_400 f_12">(Rs. 3200 OFF)</span>
								</div>
							</div>
                         </a>
						</div>
					</div>
				</div>
			</div>

		</div>


	</div>

</section>