<?php
// session_start();
echo "<pre>";
var_dump($_SESSION);