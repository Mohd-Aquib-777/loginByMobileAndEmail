<!-- ==========product================ -->

<section class="mt_80 cart">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12 text-center text-white f_14 p-0">
				<p class="fw_700 bg_12 p-0 py-1">- As per guidelines, we are only delivering essentials in govt-specified pincodes - </p>
			</div>
	
		</div>

	<div class="container">
		
		<div class="row mt-3">
			<div class="col-xl-7 col-lg-7 col-md-7 col-sm-6 cart_left ">
				<div class="check_delivery rounded d-flex justify-content-between align-items-center flex-wrap p-3 mb-2">
					<div class="f_14 fw_700 mb-2">Check delivery time & services</div>
					<div class="rounded mb-2"><button class="text-uppercase rounded tc_6 border-0 bg-white f_14 p-2" data-toggle="modal" data-target="#pincode">enter pin code</button>
                       
					</div>
				</div>
				<div class="offer p-3 mb-2">
					<div class="fw_700 f_14"><img src="assets/images/svg/discount.svg" alt="" width="20px"> Available Offers</div>
					<div class="mt-3 pl-3">
						<ul>
							<li class="fw_400 f_13 ">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
							<li class="fw_400 f_13 offer_con">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
							<li class="fw_400 f_13 offer_con">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
							<li class="fw_400 f_13 offer_con">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
							<li class="fw_400 f_13 offer_con">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
							<li class="fw_400 f_13 offer_con">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</li>
						</ul>
					</div>

					<div class="Show_More ml-3">
						<span class="f_13 fw_700 tc_6 text-capitalize cp">show more</span>
					</div>
				</div>

				<div class="conve_fee px-3 py-1 mb-2">
					<span class="f_14 fw_400"><i class="fas fa-truck"></i> Yay! <span class="fw_700">No convenience fee</span> on this order</span>
				</div>

				<div class="my_shopping_bag px-3 py-1 my-3  d-flex justify-content-between flex-wrap">
					<div class="fw_700 f_15">My Shopping Bag (1 item)</div>
					<div class="fw_700 f_15">Total: &#x20b9; 875</div>
				</div>
				<div id="catItem">
				<?php  if(isset($_SESSION['auth_user'])){ 
					include_once('control/db.php');
					$connObj = new PDOConnection();
					$conn = $connObj->connect();
					$stmt = $conn->prepare("select * from cart where username='".@$_SESSION['auth_user']."'");
					$stmt->execute();
					$cart_row = $stmt->fetchAll(PDO::FETCH_ASSOC);
					// var_dump($cart_row[]);
					$cartItemNo = count($cart_row);
					if($cart_row){
					foreach($cart_row as $val){	
				?>
					
				<div class="cart_product px-3 py-2 mb-2 ">
				 <div class="d-flex justify-content-between flex-wrap">
					
					<div class="d-flex justify-content-start">
						<div>
							<img src="assets/images/product/pro-4.webp" alt="" >
						</div>
						<div class="ml-2 cart_product_des">
							<a href="">
							<div class="fw_700 f_13 tc_0">Pure Home and Living</div>
							<div class="f_12 fw_400 tc_0">Blue Midnight Magic</div>
							<div class="f_12 fw_400 tc_3 text-capitalize">Sold by: DLF brand Pvt ltd.</div>
						    </a>
							<div class="mt-2 options">
							 <select class="fw_700 f_12">
							 	<option>Size: OnSize</option>
							 </select>
							 <select class="fw_700 f_12">
							 	<option>Qty: 1</option>
							 </select>
							 <span class="f_12 fw_400 tc_6">1 left</span>
							</div>
						</div>
					</div>
					
					<div>
						<div class="fw_700 f_13 text-right">&#x20b9; 875</div>
						<div class="fw_400 f_13 tc_3"><del>1025</del> <span class="tc_6">30% OFF</span></div>
					</div>

				 </div>

				    <div class="border-top mt-3 p-2 d-flex flex-wrap">
				    	<div class="text-uppercase fw_600 tc_3 f_14 border-right px-2 " style="cursor:pointer" onclick="removeCartItem('<?php echo $val['id']; ?>')">Remove</div>
				    	<div class="text-uppercase fw_600 tc_3 f_14 px-2"><a href="" class="tc_3 text-secondary flex-nowrap">Move to wishlist</a></div>
				    </div>

				</div>
				
				<?php } 
				}
				else echo  "cart empty";
				echo '<input type="hidden" name="" id="cartItemNo" value="'.$cartItemNo.'">';
				echo "<script>$('.countCartItem').html($('#cartItemNo').val());</script>";
				}else{echo "<script>showCartByLocaleStorage()</script>";}?>
				</div>
				
				<div class="add_wishlist px-3 py-2 mb-2">
					<div class="d-flex justify-content-between align-items-center">
						<div class="text-capitalize f_14 fw_700 tc_0"><a href="" class="text-capitalize f_14 fw_700 tc_0 text-dark"><i class="far fa-heart"></i> Add more form wishlist</a></div>
						<div><i class="fas fa-chevron-right f_14s"></i></div>
					</div>
				</div>
			</div>

			<div class="col-xl-5 col-lg-5 col-md-5 col-sm-6 cart_right">

			</div>
		</div>
    </div>
 </div>

</section>


                    <!-- ==popup== -->
                       <!-- Modal -->
						<div class="modal fade" id="pincode" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title text-capitalize" id="exampleModalLabel">enter pin code</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-body">
						        
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						        <button type="button" class="btn btn-primary">Save changes</button>
						      </div>
						    </div>
						  </div>
						</div>
