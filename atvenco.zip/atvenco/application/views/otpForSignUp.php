<?php
// session_start();



$signUpMode = '';

$existCheck = '';

$email_phone = '';

$password = '';

$otpStatus = '';

// include_once('control/existCheck.php');

// existCheck();

// echo $signUpMode.','.$existCheck.','.$email_phone.','.$password;

?>
<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	 <meta charset="UTF-8">
	 <meta name="description" content="">
	 <meta name="keywords" content="">
	 <meta name="author" content="">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link rel="shortcut icon" href="">
     <link rel="stylesheet" type="text/css" href="assets/css/style_b.css">
     <link rel="stylesheet" type="text/css" href="assets/css/login.css">

     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
     <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

     <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.min.js" integrity="sha512-EY0DoR2OkwOeyNfnJeA6x1oMLZnHLWLmPKYuwIn+7HIqeejx7w9DpUm3lhpfz8iz7K4AvKC4w8Kh8EDgKDYjWA==" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.css" integrity="sha512-JHb2JMOVqJKk0A56YvzOabc7okoyZ4Jc9vE5v/Q6L5WF+x1zru3C2nZqs5skiZoHRqDsqTnWzdpM2SqNkjrPKw==" crossorigin="anonymous" />
     

</head>
 <body>

 <?php include 'header.php'; ?>
 
<!-- sent otp by php mailer -->
<?php
  
  // require_once './vendor/autoload.php';
  
  // use Twilio\Rest\Client;

  // use PHPMailer\PHPMailer\PHPMailer;
  
  // use PHPMailer\PHPMailer\SMTP;
  
  // if($_SESSION['signUpMode']=='phone')
  // {

  //   include_once('control/otpGenerator.php');
  
  //   if(! isset($_SESSION['otpSendLimit']))
  //   {
  //     $_SESSION['otpSendLimit'] = 10;
  //   }
  
  //   $otpStatus = otpGeneator($_SESSION['otp_csrf'],$_SESSION['email_phone']);
  // }
  // // $_SESSION['otpSendLimit'] = 10;
  // if($_SESSION['signUpMode']=='email')
  // {
  //   if(! isset($_SESSION['otpSendLimit']))
  //   {
  //     $_SESSION['otpSendLimit'] = 10;
  //   }

  //   $mail = new PHPMailer();
    
  //   $smtp = SMTP::DEBUG_SERVER;
    
  //   $PHPMailer = PHPMailer::ENCRYPTION_STARTTLS;
    
  //   include_once('phpMail.php');
    
  //   $otpStatus = sendMail1($mail,$smtp,$PHPMailer);    
  // }
  
?>

<!-- ========signUp=========== -->

    <section class="bg_13">
      <form id='otpForm'>
      <div class="otp d-flex justify-content-center mt_80 py-5" >
        <div class="bg-white p-4" style="min-width: 310px;">
          <div class="img px-3 py-4">
               <img src="assets/images/svg/hacked.svg" width="55px" alt="">
          </div>
          <div class="title px-3">
            <div class="f_20 fw_700 text-dark">Verify <span class="fw_400">with</span> OTP</div>
          </div>
          <div id="otpValidation"></div>
          <div class="pl-3 pb-3">
            <div class="f_14 fw_400 tc_3">
            <?php 
              if($_SESSION['signUpMode']=='email'){echo "Send to ".$_SESSION['email_phone'];}
              if($_SESSION['signUpMode']=='phone'){echo "Send to +91".$_SESSION['email_phone'];} 
            ?>
            </div>
          </div>
          <?php  //var_dump($_SESSION['signUp_csrf']);echo "<br>"; var_dump($_REQUEST); ?>
          <?php if(@$_SESSION['login_csrf']==@$_SESSION['csrf']) { /*unset($_SESSION['login_csrf']);*/ ?>
          <div class="input_field mb-3 px-3 pt-4 pb-3">
            <input type="text" maxlength=1 name="otp1" placeholder="" autofocus>
            <input type="text" maxlength=1 name="otp2" placeholder="" >
            <input type="text" maxlength=1 name="otp3" placeholder="" >
            <input type="text" maxlength=1 name="otp4" placeholder="" >
            <input type="hidden" name="otp_csrf" value="<?=$_SESSION['otp_csrf']?>">
            <input type="hidden" name="mode" value="<?=$_SESSION['signUpMode']?>">
          </div>
          <div class="resend_otp my-2 px-3">
            <span  class="tc_6 text-uppercase fw_700 f_12 resendOTP" style="display:none;cursor:pointer">resend otp</span>
            <div class="showTime"><span class="timer"> </span> second remaining second to show resend otp button</div>
          </div>
          <?php }else{ echo "<div class='alert alert-danger'>Token Mismatch</div>";} ?>
          <div class="my-2 px-3 password">
            <span class="fw_400 f_12">Log in using </span><a href="login_2.php" class="tc_6 text-capitalize fw_700 f_13">Password</a>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Having trouble logging in?</span><a href="" class="tc_6 text-capitalize fw_700 f_13">Get help</a>
          </div>
        </div>

      </div>
    </form>
    </section>
 <script src="assets/js/otpSignUp.js"></script>
 <?php include 'footer.php'; ?>



 </body>
</html>