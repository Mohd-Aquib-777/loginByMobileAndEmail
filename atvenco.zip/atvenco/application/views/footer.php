<!-- =========footer========== -->
<footer class="bg_11 py-4">
	<div class="container">
		<div class="row">
			<div class="col-xl-2 col-lg-2 col-md-6 col-12">
				<div class="footer_content">
					<h5 class="f_13 fw_700">online shopping</h5>
					<ul type="none" class="mt-3">
						<li><a href="">Men</a></li>
						<li><a href="">Women</a></li>
						<li><a href="">Kids</a></li>
						<li><a href="">Home & Living</a></li>
						<li><a href="">Others</a> <a href="">New</a></li>
					</ul>
				</div>
			</div>
			<div class="col-xl-2 col-lg-2 col-md-6 col-12">
				<div class="footer_content">
					<h5 class="f_13 fw_700">useful links</h5>
					<ul type="none" class="mt-3">
						<li><a href="">Men</a></li>
						<li><a href="">Women</a></li>
						<li><a href="">Kids</a></li>
						<li><a href="">Home & Living</a></li>
						<li><a href="">Others</a></li>
					</ul>
				</div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-12">
				<div class="footer_content">
					<h5 class="f_13 fw_700">EXPERIENCE MYNTRA APP ON MOBILE </h5>
					<div class="d-flex mt-4">
						<div><a href=""><img src="assets/images/and.png" alt="" width="100%"></a></div>
						<div><a href=""><img src="assets/images/ios.png" alt="" width="100%"></a></div>
					</div>
					<h5 class="f_13 fw_700 mt-3">keep in touch </h5>
                     <div class="d-flex align-items-center">
                     	<div class="mr-3"><a href=""><img src="assets/images/face.png" alt="" width="20px"></a></div>
                     	<div class="mr-3"><a href=""><img src="assets/images/twitter.png" alt="" width="20px"></a></div>
                     	<div class="mr-3"><a href=""><img src="assets/images/you.png" alt="" width="25px"></a></div>
                     	<div class="mr-3"><a href=""><img src="assets/images/inst.png" alt="" width="20px"></a></div>
                     	
                     </div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-4 col-md-6 col-12 mt-xl-0 mt-lg-0 mt-4">
				<div class="footer_content">
					<div class="product_ben d-flex align-items-center">
						<div class="mr-2"><img src="assets/images/money.png" alt="" width="50px"></div>
						<div><span>100% ORIGINAL</span> guarantee for all products at myntra.com</div>
					</div>

					<div class="product_ben d-flex align-items-center mt-3">
						<div class="mr-2"><img src="assets/images/return.png" alt="" width="50px"></div>
						<div><span>Return within 30days</span> of receiving your order</div>
					</div>

					<div class="product_ben d-flex align-items-center mt-3">
						<div class="mr-2"><img src="assets/images/del.png" alt="" width="50px"></div>
						<div><span>Get free delivery</span> for every order above Rs. 799</div>
					</div>

				</div>
			</div>
		</div>
	</div>

</footer>
<script src="assets/js/login.js"></script>