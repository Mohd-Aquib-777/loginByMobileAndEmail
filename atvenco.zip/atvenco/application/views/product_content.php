<!-- ==========product================ -->
<?php
	
	// include_once('control/db.php');
	// $connObj = new PDOConnection();
	// $conn = $connObj->connect();
	// $stmt = $conn->prepare("select * from product where id=".$_REQUEST['id']);
	// $stmt->execute();
	// $product_row = $stmt->fetch(PDO::FETCH_ASSOC);
	// var_dump($product_row);
	// var_dump();

?>
<section class="mt_80 product">
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-12 text-center text-white f_14 p-0">
				<p class="fw_700 bg_12 p-0 py-1">- As per guidelines, we are only delivering essentials in govt-specified pincodes - </p>
			</div>

			<div class="search_pagination col-12 f_14">
                <a href="" class="f_14 fw_400 text-dark">Home</a> /
                <a href="" class="f_14 fw_400 text-dark">Home</a> /
                <a href="" class="f_14 fw_400 text-dark">Home</a> /
                <a href="" class="f_14 fw_700 text-dark">Home</a>
			</div>
	
		</div>

		<div class="row mt-3">
			<div class="col-xl-7 col-lg-7 col-md-7 col-sm-6 product_left ">
				<div class="row ">
				  <div class="col-xl-6 col-lg-6 col-md-6 p-1 d-xl-block d-lg-block d-md-block d-sm-block d-none">
				  	<div class="product_img border">
				  		<img src="assets/images/product/pro-2.webp" alt="" width="100%">
				  	</div>
				  </div>	
				  <div class="col-xl-6 col-lg-6 col-md-6 p-1 d-xl-block d-lg-block d-md-block d-sm-block d-none">
				  	<div class="product_img border">
				  		<img src="assets/images/product/pro-3.webp" alt="" width="100%">
				  	</div>
				  </div>	
				  <div class="col-xl-6"></div>	
				  <div class="col-xl-6"></div>	
				</div>

               <div class="swiper-container d-xl-none d-lg-none d-md-none d-sm-none d-block">
			    <div class="swiper-wrapper">
			      <div class="swiper-slide">
			        <img src="assets/images/product/pro-2.webp" alt="" width="100%">
			      </div>
			      <div class="swiper-slide">
			        <img src="assets/images/product/pro-3.webp" alt="" width="100%">
			      </div>
			     
			    </div>
			    <!-- Add Pagination -->
			    <div class="swiper-pagination"></div>
			  </div>


			</div>

			<div class="col-xl-5 col-lg-5 col-md-5 col-sm-6 product_right">
				<div class="product_desc mt-xl-0 mt-lg-0 mt-md-0 mt-2">
					<div class="f_25 fw_600 rt_20">Denial Kelin</div>
					<div class="f_18 fw_400 tc_3 mb-3 rt_15">Premium Women Silver-Toned Dial Watch DK11138-2</div>
					<div class="ratting border px-2 py-1 d-inline f_14 cp"><span class="fw_700">4.3</span> <i class="fa fa-star tc_8 f_12 mr-1"></i>| 1.6k Ratings</div>
					<hr>
					<div>
						<span class="fw_700 f_25 rt_20">Rs. 2020</span>
						<span class="fw_400 tc_3 f_18 rt_15"><del>Rs. 2051</del></span>
						<span class="fw_700 f_20 tc_10 rt_15">(60% OFF)</span>
					</div>
					<div class="tc_8 fw_700 f_14 mb-2">inclusive of all taxes</div>
					<div>
						<div class="fw_600 text-uppercase f_16 mb-2 rt_15">More color</div>
						<img src="assets/images/more.webp" alt="" width="50px" class="cp">
					</div>
					<div class="select_size mt-2">
						<div class="fw_700 f_15 text-uppercase">select size</div>
						<div class="button mt-3 cp">onesize</div>
					</div>
					<div class="buy_button mt-4 d-flex">
					<?php if(isset($_SESSION['auth_user'])){ ?>
						<button class="py-2 rounded text-uppercase text-white font-weight-bold rt_15" onclick="addToCart('<?php //echo $product_row['id']; ?>')"><i class="fas fa-shopping-bag text-white mr-1 rt_15"></i> Add To bag</button>
					<?php }else{ ?>
						<button class="py-2 rounded text-uppercase text-white font-weight-bold rt_15"  onclick="addToCartByLocalStorage('<?php //echo $product_row['id']; ?>')"><i class="fas fa-shopping-bag text-white mr-1 rt_15"></i> Add To bag</button>	
					<?php } ?>
						<!-- <button class="py-2 rounded text-uppercase text-white font-weight-bold rt_15"  onclick="addToCartByLocalStorage('<?php //echo $product_row['id']; ?>')"><i class="fas fa-shopping-bag text-white mr-1 rt_15"></i> Add To bag</button> -->
						<button class="py-2 ml-2 rounded bg-white text-uppercase text-dark font-weight-bold border rt_15"><i class="far fa-heart mr-1 rt_15"></i> wishlist</button>
					</div>
					
					<hr>

					<div>
						<span class="fw_700 f_14">Rs. 2020</span>
						<span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						<span class="fw_700 f_14 tc_10">(60% OFF)</span>
					</div>
					<div class="f_14 ">
						<a href="" class="text-dark">Seller:<span class="tc_6 fw_600">RtailNet</span></a>
					</div>
					<div class="f_14">
						<a href="" class="tc_6 fw_600"><span class="tc_6">1 more seller available</span></a>
					</div>

					<hr>

					<div class="deliver_option">
						<div class="f_16 fw_600 mb-3 text-uppercase">Delivery Options <i class="fa fa-truck"></i></div>
						<input type="text" name="" class="bg-white py-2 px-3 rounded border" placeholder="Enter a PIN code">
						<div class="f_12 mt-2">Please enter PIN code to check delivery time & Pay on Delivery Availability</div>
						<ul type="none" class="mt-2 rt_14">
							<li>100% Original Products</li>
							<li>Free Delivery on order above Rs. 799</li>
							<li>Pay on delivery might be available</li>
							<li>Easy 30 days returns</li>
							<li>This item is only returnable and not exchangeable</li>
							<li>Try & Buy might be available</li>
						</ul>
						<div class="f_15 fw_700 mb-3 text-uppercase">Best Offers <i class="fa fa-tag"></i></div>
						<div class="f_14">This product is already at its best price</div>

						<div class="f_15 fw_700 my-3 text-uppercase">EMI option available </div>
						<div class="f_14">EMI starting from Rs.95/month</div>

					</div>

					<hr>

					<div class="product_detail">
						<div class="f_15 fw_700 mb-3 text-uppercase">Product Details </div>
						<div class="f_15 rt_14">
							<p>Case style: Analogue watch withnbsp;a circular case, has a fixed bezel with stone-studded detail and a stainless steel backDial style: Silver-toned dialFeatures: A screw to reset the time
							Strap style: Steel-toned stainless steel strap,nbsp;secured with a fold-over claspWater-resistant up to 30 mComes in a signature Daniel Klein caseWarranty: 2 years on machine, battery and 6 months on plating
							</p>
							<p>Case style: Analogue watch withnbsp;a circular case, has a fixed bezel with stone-studded detail and a stainless steel backDial style: Silver-toned dialFeatures: A screw to reset the time
							Strap style: Steel-toned stainless steel strap,nbsp;secured with a fold-over claspWater-resistant up to 30 mComes in a signature Daniel Klein caseWarranty: 2 years on machine, battery and 6 months on plating
							</p>
						</div>

						<div class="f_15 fw_700 my-3 text-uppercase">Size & Fit </div>
						<div class="f_15">Dial width: 27 mm</div>
						<div class="f_15">Strap width: 15 mm</div>

						<div class="f_15 fw_700 my-3 text-uppercase">Specifications </div>
						<div class="d-flex justify-content-between">
							<div class="w-100 px-2">
								<div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>

							    <div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>

							    <div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>


							</div>
							<div class="w-100 px-2">
								<div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>

							    <div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>

							    <div class="border-bottom w-100 my-2 py-1">
								 <div class="tc_3 f_12">Display</div>
								 <div class="f_15">Analogue</div>
							    </div>


							</div>
						</div>

						<div class="f_14 fw_700 tc_6 cp px-2">See More</div>

					</div>

					<hr>

					<div class="ratting_des">
						<div class="f_15 fw_700 mb-3 text-uppercase">Ratings </div>

						<div class="d-flex">
						 <div class="border-right p-3">
						 	<div class="f_40">4.3 <i class="fa fa-star tc_8 f_15"></i></div>
						 	<div class="f_14">1.6k Verified Buyers</div>
						 </div>	
						 <div class="p-3">
						 	<div class="d-flex align-items-center tc_3 f_13">5 <i class="fa fa-star tc_9 f_9 mx-1"></i> <div style="height: 3px;width: 100px;background-color: #4FC1A9;margin:0 5px;"> </div>918</div>

						 	<div class="d-flex align-items-center tc_3 f_13">4 <i class="fa fa-star tc_9 f_9 mx-1"></i> <div style="height: 3px;width: 100px;background-color: #4FC1A9;margin:0 5px;"> </div>918</div>

						 	<div class="d-flex align-items-center tc_3 f_13">3 <i class="fa fa-star tc_9 f_9 mx-1"></i> <div style="height: 3px;width: 100px;background-color: #4FC1A9;margin:0 5px;"> </div>918</div>

						 	<div class="d-flex align-items-center tc_3 f_13">2 <i class="fa fa-star tc_9 f_9 mx-1"></i> <div style="height: 3px;width: 100px;background-color: #4FC1A9;margin:0 5px;"> </div>918</div>

						 	<div class="d-flex align-items-center tc_3 f_13">1 <i class="fa fa-star tc_9 f_9 mx-1"></i> <div style="height: 3px;width: 100px;background-color: #4FC1A9;margin:0 5px;"> </div>918</div>

						 </div>	
						</div>

					</div>

					<hr>

					<div class="customer_review">
						<div class="f_15 fw_700 mb-3 text-uppercase">Customer Reviews (352) </div>

						<div class="f_15 rt_14"><span class="bg_12 f_11 text-white">5<i class="fa fa-star f_10 text-white"></i></span> Nice watch nice service by myntra ,nuce price got discount from myntra, thanks </div>
						<div class="mt-2">
							<img src="assets/images/review.webp" alt="" width="70px" class="ml-2 mb-2">
							<img src="assets/images/review.webp" alt="" width="70px" class="ml-2 mb-2">
							<img src="assets/images/review.webp" alt="" width="70px" class="ml-2 mb-2">
							<img src="assets/images/review.webp" alt="" width="70px" class="ml-2 mb-2">
						</div>

						<div class="f_14 tc_3 ml-2 d-flex justify-content-between my-2">
							<div>Ronak Sharma | 3 Feb 2021</div>
							<div class="d-flex justify-content-between align-items-center">
								<div class="mr-3"><i class="far fa-thumbs-up"></i> 89</div>
								<div><i class="far fa-thumbs-down"></i> 42</div>
							</div>
						</div>

						
					</div>

					<hr>



				</div>
			</div>
		</div>


		<!-- ===similar product=== -->

		<div class="row">
			<div class="col-11 mx-auto">
				<h4 class="text-uppercase f_15 fw_700">Similar products</h4>
			</div>

			<div class="col-xl-2 offset-xl-1 offset-lg-1 col-lg-2 col-md-3 col-sm-4 col-12 mt-3">
				<div class="similar_product_des border">
					<a href="">
					<div class="img d-flex justify-content-center align-items-center">
						<img src="assets/images/product/pro-3.webp" width="150px" alt="">
					</div>
					<div class=" border-top p-2">
						<div class="f_14 fw_700 text-dark">Denial Kelin</div>
						<div class="fw_400 f_13 tc_3">Unisex Storm Smart Watch</div>
							<div>
						 <span class="fw_700 f_14 text-dark">Rs. 2020</span>
						 <span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						 <span class="fw_700 f_14 tc_10">(60% OFF)</span>
					    </div>
					</div>
				    </a>
				</div>
			</div>

			<div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 mt-3">
				<div class="similar_product_des border">
					<a href="">
					<div class="img d-flex justify-content-center align-items-center">
						<img src="assets/images/product/pro-3.webp" width="150px" alt="">
					</div>
					<div class=" border-top p-2">
						<div class="f_14 fw_700 text-dark">Denial Kelin</div>
						<div class="fw_400 f_13 tc_3">Unisex Storm Smart Watch</div>
							<div>
						 <span class="fw_700 f_14 text-dark">Rs. 2020</span>
						 <span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						 <span class="fw_700 f_14 tc_10">(60% OFF)</span>
					    </div>
					</div>
				    </a>
				</div>
			</div>

			<div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 mt-3">
				<div class="similar_product_des border">
					<a href="">
					<div class="img d-flex justify-content-center align-items-center">
						<img src="assets/images/product/pro-3.webp" width="150px" alt="">
					</div>
					<div class=" border-top p-2">
						<div class="f_14 fw_700 text-dark">Denial Kelin</div>
						<div class="fw_400 f_13 tc_3">Unisex Storm Smart Watch</div>
							<div>
						 <span class="fw_700 f_14 text-dark">Rs. 2020</span>
						 <span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						 <span class="fw_700 f_14 tc_10">(60% OFF)</span>
					    </div>
					</div>
				    </a>
				</div>
			</div>

			<div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 mt-3">
				<div class="similar_product_des border">
					<a href="">
					<div class="img d-flex justify-content-center align-items-center">
						<img src="assets/images/product/pro-3.webp" width="150px" alt="">
					</div>
					<div class=" border-top p-2">
						<div class="f_14 fw_700 text-dark">Denial Kelin</div>
						<div class="fw_400 f_13 tc_3">Unisex Storm Smart Watch</div>
							<div>
						 <span class="fw_700 f_14 text-dark">Rs. 2020</span>
						 <span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						 <span class="fw_700 f_14 tc_10">(60% OFF)</span>
					    </div>
					</div>
				    </a>
				</div>
			</div>

			<div class="col-xl-2 col-offset-1 col-lg-2 col-md-3 col-sm-4 col-12 mt-3">
				<div class="similar_product_des border">
					<a href="">
					<div class="img d-flex justify-content-center align-items-center">
						<img src="assets/images/product/pro-3.webp" width="150px" alt="">
					</div>
					<div class=" border-top p-2">
						<div class="f_14 fw_700 text-dark">Denial Kelin</div>
						<div class="fw_400 f_13 tc_3">Unisex Storm Smart Watch</div>
							<div>
						 <span class="fw_700 f_14 text-dark">Rs. 2020</span>
						 <span class="fw_400 tc_3 f_14"><del>Rs. 2051</del></span>
						 <span class="fw_700 f_14 tc_10">(60% OFF)</span>
					    </div>
					</div>
				    </a>
				</div>
			</div>

		</div>

		


	</div>

</section>