<?php
  // session_start();
  $_SESSION['login_csrf'] = md5(rand(1000,9000));
?>
<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	 <meta charset="UTF-8">
	 <meta name="description" content="">
	 <meta name="keywords" content="">
	 <meta name="author" content="">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link rel="shortcut icon" href="">
     <link rel="stylesheet" type="text/css" href="assets/css/style_b.css">
     <link rel="stylesheet" type="text/css" href="assets/css/login.css">

     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

     <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

     <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.min.js" integrity="sha512-EY0DoR2OkwOeyNfnJeA6x1oMLZnHLWLmPKYuwIn+7HIqeejx7w9DpUm3lhpfz8iz7K4AvKC4w8Kh8EDgKDYjWA==" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.css" integrity="sha512-JHb2JMOVqJKk0A56YvzOabc7okoyZ4Jc9vE5v/Q6L5WF+x1zru3C2nZqs5skiZoHRqDsqTnWzdpM2SqNkjrPKw==" crossorigin="anonymous" />
     

</head>
 <body>

 <?php include 'header.php'; ?>
 
<!-- ========login=========== -->

    <section class="bg_13 login_2Section">
      <form action="Login_2/login" id="login_2Form" method="post">
      <div class="login_2 d-flex justify-content-center mt_80 py-5" >
        <div class="bg-white p-4" style="min-width: 350px;">
          
          <div class="title p-3">
            <div class="f_20 fw_700 text-dark">Login to your account</div>
          </div>
          <div id="login_2Validation" class="px-3">
            <div  class=""></div> 
          </div>
          <div class="input_field mb-3 px-3">
            <input type="text" name="email_phone" placeholder="Email or Mobile Number">
          </div>
          <div class="input_field mb-3 px-3">
            <input type="text" name="password" placeholder="Password">
          </div>
          <input type="hidden" name="csrf" value="<?=$_SESSION['login_csrf']?>">
          <div class=" px-3 text-center">
            <button class="button text-uppercase text-white fw_700 bg_8 py-2 w-100 border-0 login_2Submit">Login</button>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Forgot your password?</span><a href="reset.php" class="tc_6 text-capitalize fw_700 f_13">Reset here</a>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12" >Create Account?</span><span style="cursor:pointer" class="tc_6 text-capitalize fw_700 f_13 showSignUpForm">Click Here </sapn>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Having trouble logging in?</span><a href="" class="tc_6 text-capitalize fw_700 f_13">Get help</a>
          </div>
        </div>

      </div>
    </form>
    </section>

    <!-- ========signup=========== -->

    <section class="bg_13 signUpSection" style="display:none">
      <form action="OtpForSignUp" id="signUpForm" method="post">
      <div class="login_2 d-flex justify-content-center mt_80 py-5" >
        <div class="bg-white p-4" style="min-width: 350px;">
          
          <div class="title p-3">
            <div class="f_20 fw_700 text-dark">Create your account</div>
          </div>
          <div id="signUpValidation" class="px-3">
            <div  class=""></div> 
          </div>
          <div class="input_field mb-3 px-3">
            <input type="text" name="email_phone" placeholder="Email or Mobile Number">
          </div>
          <div class="input_field mb-3 px-3" style="position:relative">
            <input type="password" name="password" placeholder="Password">
            <i class="fa fa-eye showPassword"  aria-hidden="true"></i>
            <i class="fa fa-eye-slash hidePassword" style="display:none" aria-hidden="true"></i>
          </div>
          <input type="hidden" name="csrf" value="<?=$_SESSION['login_csrf']?>">
          <div class=" px-3 text-center">
            <button class="button text-uppercase text-white fw_700 bg_8 py-2 w-100 border-0 signUpSubmit">Sign-Up</button>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Login To Your Account?</span><span class="tc_6 text-capitalize fw_700 f_13 showLoginForm">Click here</span>
          </div>
          <div class="help px-3 my-3">
            <span class="fw_400 f_12">Having trouble logging in?</span><a href="" class="tc_6 text-capitalize fw_700 f_13">Get help</a>
          </div>
        </div>

      </div>
    </form>
    </section>

 <script src="assets/js/login_2.js"></script>
 <script src="assets/js/showSignUpForm.js"></script>
 <?php include 'footer.php'; ?>


  
 </body>
</html>