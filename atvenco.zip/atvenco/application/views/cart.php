<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>cart</title>
	 <meta charset="UTF-8">
	 <meta name="description" content="">
	 <meta name="keywords" content="">
	 <meta name="author" content="">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link rel="shortcut icon" href="">
     <link rel="stylesheet" type="text/css" href="assets/css/style_b.css">
     <link rel="stylesheet" type="text/css" href="assets/css/cart.css">

     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  
     <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

     <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.min.js" integrity="sha512-EY0DoR2OkwOeyNfnJeA6x1oMLZnHLWLmPKYuwIn+7HIqeejx7w9DpUm3lhpfz8iz7K4AvKC4w8Kh8EDgKDYjWA==" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.5.7/swiper-bundle.css" integrity="sha512-JHb2JMOVqJKk0A56YvzOabc7okoyZ4Jc9vE5v/Q6L5WF+x1zru3C2nZqs5skiZoHRqDsqTnWzdpM2SqNkjrPKw==" crossorigin="anonymous" />
     
     <script src="assets/js/LocalCart.js"></script> 
</head>
 <body>

 <?php include 'header.php'; ?>
 
 <?php include 'cart_content.php'; ?>
 
 <?php include 'footer.php'; ?>


  

 
 	
 <script>
   $(document).ready(function(){
    $('.cart_left .Show_More').click(function(){
        $('.cart_left .offer .offer_con').toggle();
    })
   })   
 </script>	
 </body>
</html>